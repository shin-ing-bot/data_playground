package com.springboot.demo2.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springboot.demo2.dto.Detail2;

@Repository
public interface Detail2Repository extends JpaRepository<Detail2, Integer> {

}
