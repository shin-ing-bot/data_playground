package com.springboot.demo2.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springboot.demo2.dto.Product1;

@Repository
public interface Product1Repository extends JpaRepository<Product1, Integer> {

}
