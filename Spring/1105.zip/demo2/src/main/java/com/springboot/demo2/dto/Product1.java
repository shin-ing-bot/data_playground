package com.springboot.demo2.dto;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import lombok.Data;

@Entity //db 연결해서 테이블 생성
@Data
public class Product1 {
	@Id //기본키
	@GeneratedValue(strategy = GenerationType.IDENTITY) //자동중가
	private Integer id;
	private String name;
	private float price;
	
	
	//1:1 product와 detail 연결(단방향)
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="detail_id")
	private Detail1 detail; //외래키
}
