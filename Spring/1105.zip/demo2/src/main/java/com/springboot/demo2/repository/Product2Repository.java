package com.springboot.demo2.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springboot.demo2.dto.Product2;

@Repository
public interface Product2Repository extends JpaRepository<Product2, Integer> {

}
