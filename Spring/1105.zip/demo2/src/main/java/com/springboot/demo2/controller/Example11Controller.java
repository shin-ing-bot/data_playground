package com.springboot.demo2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fasterxml.jackson.annotation.JsonCreator.Mode;
import com.springboot.demo2.dto.Detail1;
import com.springboot.demo2.dto.Detail2;
import com.springboot.demo2.dto.Product1;
import com.springboot.demo2.dto.Product2;
import com.springboot.demo2.repository.Detail2Repository;
import com.springboot.demo2.repository.Product2Repository;

@Controller
@RequestMapping("/ch14/exam06")
public class Example11Controller {
	
	@Autowired
	Product2Repository product2Repository;
	@Autowired
	Detail2Repository detail2Repository;
	
	@GetMapping
	public String requestInsert(Model model) {
		Product2 product = new Product2();
		product.setName("갤럭시...");
		product.setPrice(999);
		
		Detail2 detail = new Detail2();
		detail.setDescription("안드로이드폰");
		detail.setWeight(196f);
		detail.setHeight(158.5f);
		detail.setWeight(75.9f);
		
		//product 출력
		detail.setProduct(product);
		detail2Repository.save(detail); //db에서 삽입
		
		Iterable<Product2> productList = product2Repository.findAll();
		Iterable<Detail2> detailList = detail2Repository.findAll();
		
		model.addAttribute("productList", productList);
		model.addAttribute("detailList", detailList);
		
		return "viewPage10";
	}
}
