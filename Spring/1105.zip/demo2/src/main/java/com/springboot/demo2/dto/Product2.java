package com.springboot.demo2.dto;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrimaryKeyJoinColumn;
import lombok.Data;

@Entity //db 연결해서 테이블 생성
@Data
public class Product2 {
	@Id //기본키
	@GeneratedValue(strategy = GenerationType.IDENTITY) //자동중가
	private Integer id;
	private String name;
	private float price;
	
	
	//1:1 product와 detail 연결(양방향 : 서로 참조)
	@OneToOne(mappedBy="product", cascade=CascadeType.ALL)
	@PrimaryKeyJoinColumn //기본키를 외래키로 설정 => detail에서 product의 기본키를 생성
	private Detail2 detail; //외래키
}
