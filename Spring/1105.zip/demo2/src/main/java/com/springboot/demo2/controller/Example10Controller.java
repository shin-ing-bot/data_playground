
package com.springboot.demo2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fasterxml.jackson.annotation.JsonCreator.Mode;
import com.springboot.demo2.dto.Detail1;
import com.springboot.demo2.dto.Product1;
import com.springboot.demo2.repository.Detail1Repository;
import com.springboot.demo2.repository.Product1Repository;

@Controller
@RequestMapping("/ch14/exam05")
public class Example10Controller {
	
	@Autowired
	Product1Repository productRepository;
	@Autowired
	Detail1Repository detailRepository;
	
	@GetMapping
	public String requestInsert(Model model) {
		Product1 product = new Product1();
		product.setName("아이폰...");
		product.setPrice(1000000);
		
		Detail1 detail = new Detail1();
		detail.setDescription("ios 폰");
		detail.setWeight(196f);
		detail.setHeight(158.5f);
		detail.setWeight(75.9f);
		
		//prodct에서 detail 참조
		product.setDetail(detail);
		productRepository.save(product); //db에 저장(삽입)

		//화면 결과 출력
		Iterable<Product1> productList = productRepository.findAll();
		Iterable<Detail1> detailList = detailRepository.findAll();
		
		model.addAttribute("productList", productList);
		model.addAttribute("detailList", detailList);
		
		return "viewPage10";
	}
}
