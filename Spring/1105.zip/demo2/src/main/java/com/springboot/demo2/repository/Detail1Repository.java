package com.springboot.demo2.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springboot.demo2.dto.Detail1;

@Repository
public interface Detail1Repository extends JpaRepository<Detail1, Integer> {

}
