package com.springboot.demo2.dto;

import jakarta.annotation.Generated;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToOne;
import lombok.Data;

@Entity
@Data
public class Detail2 {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String description;
	private float weight;
	private float height;
	private float width;
	
	//detail에서 prodcut 참조
	@OneToOne
	@JoinColumn(name="product_id")
	@MapsId // 외래키를 기본키로 공유
	private Product2 product;
}
